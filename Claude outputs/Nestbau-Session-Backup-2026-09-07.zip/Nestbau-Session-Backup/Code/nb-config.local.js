/* Nestbau v2 – Lokale Konfiguration (nicht ins Repo commiten) */
NB.configure({
  google: {
    clientId: "190039126848-6qi0lv0soq1h9kcmiei12mo1ug1ptppk.apps.googleusercontent.com"
  }
});
